// src/CryptoChart.js
import React, { useEffect, useRef } from 'react';
import { TradingviewWidgetModule } from 'tradingview-widget';

const CryptoChart = ({ symbol }) => {
    const chartRef = useRef();

    useEffect(() => {
        if (chartRef.current) {
            new TradingviewWidgetModule({
                container_id: chartRef.current.id,
                autosize: true,
                symbol: symbol,
                interval: '60',
                timezone: 'Etc/UTC',
                theme: 'light',
                style: '1',
                locale: 'en',
                toolbar_bg: '#f1f3f6',
                enable_publishing: false,
                allow_symbol_change: true,
                details: true,
                container_width: '100%',
                container_height: '100%',
                withdateranges: false,
                hide_side_toolbar: false,
                allow_multiple_instances: true,
                studies: [
                    'StochasticRSI@tv-basicstudies',
                    'MACD@tv-basicstudies',
                    'MASimple@tv-basicstudies',
                ],
                loading_screen: { backgroundColor: '#ffffff' },
            });
        }
    }, [symbol]);

    return <div id={`chart-${symbol}`} ref={chartRef} style={{ width: '30%', height: '400px', marginTop: '1rem' }} />;
};

export default CryptoChart;
